package com.sanjay;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class URLTesting {

	
	@RequestMapping("/urltest")
	public String URLDis() throws InterruptedException
	{
	System.setProperty("webdriver.chrome.driver","E:\\SanjayProjects\\SpringBoot\\src\\main\\resources\\chromedriver.exe");  
  	WebDriver driver=new ChromeDriver();  
  	driver.navigate().to("localhost:8181");  
     driver.manage().window().fullscreen();
     
    	driver.findElement(By.className("dropbtn")).click();
    	Thread.sleep(3000);
    	driver.findElement(By.linkText("Bangalore")).click();
    	Thread.sleep(4000);
    	driver.findElement(By.linkText("home page..")).click();
    	Thread.sleep(3000);
    	driver.findElement(By.className("dropbtn")).click();
    	Thread.sleep(3000);
    	driver.findElement(By.linkText("Chennai")).click();
    	Thread.sleep(4000);
    	driver.findElement(By.linkText("home page..")).click();
    	Thread.sleep(3000);
    	driver.close();
  return "index";
	}
}
